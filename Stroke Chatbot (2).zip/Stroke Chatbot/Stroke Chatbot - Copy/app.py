from flask import Flask, request, jsonify
from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/index', methods=['GET','POST'])
def submit():
    if request.method == 'POST':
        #data = request.form.to_dict(flat=False)
        data = request.data.decode('utf-8')
        '''
        data = request.data.decode('utf-8')

        # Personal Information
        email = request.form['email']
        first_name = request.form['first-name']
        last_name = request.form['last-name']
        age = request.form['age']
        tshirt_size = request.form['tshirt-size']
        country = request.form['country']
        city = request.form['city']
        mobile_number = request.form['mobile-number']
        emergency_contact_name = request.form['emergency-contact-name']
        emergency_contact_number = request.form['emergency-contact-number']

        # Medical Information
        allergies = request.form.get('allergies', '')
        prescribed_medication = request.form.get('prescribed-medication', '')
        medical_aid = request.form['medical-aid']
        medical_aid_number = request.form['medical-aid-number']
        medical_aid_plan = request.form['medical-aid-plan']
        principal_member = request.form['principal-member']
        dietary_restrictions = request.form['dietary-restrictions']

        # Payment Information
        pickup_location = request.form['pickup-location']
        dropoff_location = request.form['dropoff-location']
        #proof_of_payment = request.files['proof-of-payment']
        region_specific_cost = request.form['region-specific-cost']
        payment_confirmation = request.form['payment-confirmation']

        #return render_template('index.html')
        '''

        return jsonify({"email": data})
    else:
        return jsonify({"email": "testing"})

if __name__ == '__main__':
    app.run(debug=True)

