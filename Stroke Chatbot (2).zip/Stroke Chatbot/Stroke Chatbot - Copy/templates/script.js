// script.js
function showSection(sectionId) {
    document.querySelectorAll('.section').forEach(section => {
        section.style.display = 'none';
    });
    document.getElementById(sectionId).style.display = 'block';
}

const personalInfoFields = [
    'email',
    'first-name',
    'last-name',
    'age',
    'tshirt-size',
    'country',
    'city',
    'mobile-number',
    'emergency-contact-name',
    'emergency-contact-number'
];

const medicalInfoFields = [
    'allergies',
    'prescribed-medication',
    'medical-aid',
    'medical-aid-number',
    'medical-aid-plan',
    'principal-member',
    'dietary-restrictions'
];

const paymentInfoFields = [
    'pickup-location',
    'dropoff-location',
    'proof-of-payment',
    'region-specific-cost',
    'payment-confirmation'
];

function validateAndShowSection(sectionId, fields) {
    let allFilled = true;

    fields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (!field.value.trim()) {
            allFilled = false;
            field.classList.add('error');
        } else {
            field.classList.remove('error');
        }
    });

    if (allFilled) {
        showSection(sectionId);
    } else {
        alert('Please fill in all required fields.');
    }
}

function validateAndSubmit() {
    let allFilled = true;

    paymentInfoFields.forEach(fieldId => {
        const field = document.getElementById(fieldId);
        if (!field.checked && !field.value.trim()) {
            allFilled = false;
            field.classList.add('error');
        } else {
            field.classList.remove('error');
        }
    });

    if (allFilled) {
        // Form submission logic here
        alert('Form submitted successfully.');
    } else {
        alert('Please fill in all required fields.');
    }
}
