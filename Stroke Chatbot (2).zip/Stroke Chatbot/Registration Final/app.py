from flask import Flask, request, jsonify, render_template
from flask import redirect, url_for, session, flash
import os
import mysql.connector
import random
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders

app = Flask(__name__)

app.secret_key = os.urandom(24)  # This is used to encrypt session data

# Admin credentials
admin_user = {
    "email": "admin@gmail.com",
    "password": "password123"
}

def send_registration_email(receiver_email, first_name, tribe, room, details):
    # Email configuration
    sender_email = "y17967733@gmail.com"
    password = "jevd zmsv tvty hvdu"
    
    # Email subject and body
    subject = "Youth Week Conference Registration Confirmation"
    body = f"""
Hi {first_name},

Congratulations on successfully registering for the Youth Week Conference!

We are excited to inform you that you have been allocated to:
Tribe: {tribe}
Room: {room}

Attached are the details you provided during registration.

Please let us know if you have any questions or need further assistance.

Best regards,
Youth Week Conference Team
"""

    # Create the email headers and body
    message = MIMEMultipart()
    message["From"] = sender_email
    message["To"] = receiver_email
    message["Subject"] = subject
    message.attach(MIMEText(body, "plain"))

    # Create the Excel file
    df = pd.DataFrame([details])
    excel_filename = "registration_details.xlsx"
    df.to_excel(excel_filename, index=False)

    # Attach the Excel file
    with open(excel_filename, "rb") as attachment:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(attachment.read())
        encoders.encode_base64(part)
        part.add_header(
            "Content-Disposition",
            f"attachment; filename={excel_filename}",
        )
        message.attach(part)

    # Connect to the SMTP server and send the email
    try:
        # Create a secure SSL context
        context = smtplib.ssl.create_default_context()

        with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
            server.login(sender_email, password)
            server.sendmail(sender_email, receiver_email, message.as_string())

        print("Email sent successfully!")
    except Exception as e:
        print(f"Error: {e}")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/index.html')
def index_2():
    return render_template('index.html')

@app.route('/successfully_registered.html')
def success():
    return render_template('successfully_registered.html')

# For admin logging in
@app.route('/authentication', methods=['POST'])
def login2():
    data = request.json  # Parse JSON data from the request
    email = data.get('email')
    password = data.get('password')

    if email == admin_user['email'] and password == admin_user['password']:
            session['logged_in'] = True
            print("Matches")
            return jsonify({'message': 'Successful'}), 200
    else:
        print("Don't match")
        flash('Invalid credentials. Please try again.')
        return jsonify({'message': 'Unsuccessful'}), 200

    return render_template('login.html')

@app.route('/login.html', methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/logout', methods=['POST'])
def logout():
    session.pop('logged_in', None)
    return jsonify({'message': 'Successful'}), 200

@app.route('/admin_interface.html')
def registered_users():
    if not session.get('logged_in'):
        return render_template('login.html')
    return render_template("admin_interface.html")

@app.route('/user_details.html', methods=['GET'])
def user_details():
    if not session.get('logged_in'):
        return render_template('login.html')
    user_id = request.args.get('id')

    # Connect to MySQL database
    try:
        db = mysql.connector.connect(
            host="193.203.168.104",
            user="u468884535_db_regist",
            password="LqZ$@Z4/m",
            database="u468884535_registration"
        )

        cursor = db.cursor(dictionary=True)

        # Query to fetch user details
        query = "SELECT email, first_name, last_name, age, tshirt_size, country, city, mobile_number, emergency_contact_name, emergency_contact_number, allergies, prescribed_medication, medical_aid, medical_aid_number, medical_aid_plan, principal_member, dietary_restrictions, pickup_location, dropoff_location, region_specific_cost, payment_confirmation,tribe_allocation, room_number_allocation FROM registrations WHERE id = %s"
        cursor.execute(query, (user_id,))
        user_details = cursor.fetchone()

        cursor.close()
        db.close()

        if user_details:
            return render_template('user_details.html', user=user_details)
        else:
            return 'User not found.'

    except mysql.connector.Error as err:
        print(f"Error accessing MySQL database: {err}")
        return 'Database error.'

@app.route('/user_details', methods=['POST'])
def get_user_details():
    return jsonify({'message': "done"})

@app.route('/get_users', methods=['GET'])
def get_users():
    try:
        db = mysql.connector.connect(
            host="193.203.168.104",
            user="u468884535_db_regist",
            password="LqZ$@Z4/m",
            database="u468884535_registration"
        )

        cursor = db.cursor(dictionary=True)  # Use dictionary cursor for easy JSON conversion

        # Fetch users from the database
        #query = "SELECT id ,email, concat(first_name,' ',last_name) as name, country, city, mobile_number FROM registrations"
        query = "SELECT id, email,concat(first_name,' ',last_name) as name, first_name, last_name, age, tshirt_size, country, city, mobile_number, emergency_contact_name, emergency_contact_number, allergies, prescribed_medication, medical_aid, medical_aid_number, medical_aid_plan, principal_member, dietary_restrictions, pickup_location, dropoff_location, region_specific_cost, payment_confirmation, tribe_allocation, room_number_allocation FROM registrations"
        cursor.execute(query)
        users = cursor.fetchall()

        # Close cursor and database connection
        cursor.close()
        db.close()

        return jsonify(users)

    except mysql.connector.Error as err:
        print(f"Error fetching users from database: {err}")
        return jsonify({'error': 'Database error'})

@app.route('/send_form', methods=['POST'])
def submit():
    if request.method == 'POST':
        data = request.json  # Parse JSON data from the request

        #print(data)

        # Extract relevant fields from data
        # Personal Information
        email = data.get('email')
        first_name = data.get('first-name')
        last_name = data.get('last-name')
        age = data.get('age')
        tshirt_size = data.get('tshirt-size')
        country = data.get('country')
        city = data.get('city')
        mobile_number = data.get('mobile-number')
        emergency_contact_name = data.get('emergency-contact-name')
        emergency_contact_number = data.get('emergency-contact-number')

        # Medical Information
        allergies = data.get('allergies')
        prescribed_medication = data.get('prescribed-medication')
        medical_aid = data.get('medical-aid')
        medical_aid_number = data.get('medical-aid-number')
        medical_aid_plan = data.get('medical-aid-plan')
        principal_member = data.get('principal-member')
        dietary_restrictions = data.get('dietary-restrictions')

        # Payment Information
        pickup_location = data.get('pickup-location')
        dropoff_location = data.get('dropoff-location')
        #proof_of_payment = request.files['proof-of-payment')
        region_specific_cost = data.get('region-specific-cost')
        payment_confirmation = data.get('payment-confirmation')

        # Database connection
        db = mysql.connector.connect(
            host="193.203.168.104",
            user="u468884535_db_regist",
            password="LqZ$@Z4/m",
            database="u468884535_registration"
        )

        cursor = db.cursor()
        
        sql = """
            INSERT INTO registrations (email, first_name, last_name, age, tshirt_size, country, city, mobile_number, emergency_contact_name, emergency_contact_number, allergies, prescribed_medication, medical_aid, medical_aid_number, medical_aid_plan, principal_member, dietary_restrictions, pickup_location, dropoff_location, region_specific_cost, payment_confirmation, tribe_allocation, room_number_allocation)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
        """

        list_tribes = ["Team A", "Team B", "Team C", "Team D"]
        list_room_numbers = ["Room A", "Room B", "Room C", "Room D", "Room E"]
        tribe_allocation = random.choice(list_tribes)
        room_number_allocation = random.choice(list_room_numbers)

        values = (
            email,
            first_name,
            last_name,
            age,
            tshirt_size,
            country,
            city,
            mobile_number,
            emergency_contact_name,
            emergency_contact_number,
            allergies,
            prescribed_medication,
            medical_aid,
            medical_aid_number,
            medical_aid_plan,
            principal_member,
            dietary_restrictions,
            pickup_location,
            dropoff_location,
            region_specific_cost,
            payment_confirmation,
            tribe_allocation,
            room_number_allocation
        )

        # Convert the tuple to a dictionary
        keys = [
            'email',
            'first_name',
            'last_name',
            'age',
            'tshirt_size',
            'country',
            'city',
            'mobile_number',
            'emergency_contact_name',
            'emergency_contact_number',
            'allergies',
            'prescribed_medication',
            'medical_aid',
            'medical_aid_number',
            'medical_aid_plan',
            'principal_member',
            'dietary_restrictions',
            'pickup_location',
            'dropoff_location',
            'region_specific_cost',
            'payment_confirmation',
            'tribe_allocation',
            'room_number_allocation'
        ]

        details = dict(zip(keys, values))

        try:
            cursor.execute(sql, values)
            db.commit()
            cursor.close()

            tribe = "Team A"
            room = "Block 1, Room Number 2"

            send_registration_email(email.strip(), first_name, tribe_allocation, room_number_allocation, details)

            return jsonify({'message': 'Form submitted successfully'}), 200
        except Exception as e:
            db.rollback()
            print(str(e))
            cursor.close()
            return jsonify({'error': str(e)}), 500
            

        #return response

if __name__ == '__main__':
    app.run(debug=True)

